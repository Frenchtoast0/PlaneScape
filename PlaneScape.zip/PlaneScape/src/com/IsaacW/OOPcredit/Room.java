package com.IsaacW.OOPcredit;

public abstract class Room
{
    private static String name;
    private boolean looted;

    public Room(String name)
    {
        this.name = name;
        looted = false;
    }

    /**
     * When looting is done, the room's state is changed
     * so it can't be looted anymore.
     */
    public void doneLoot()
    {
        looted = true;
    }

    /**
     * Abstract class for looting rooms.
     * @return the looted object
     */
    public abstract Thing loot();

    /**
     *Returns the state of whether the room is looted
     * or not
     *
     * @return looted or not
     */
    public boolean isLooted()
    {
        return looted;
    }

}
