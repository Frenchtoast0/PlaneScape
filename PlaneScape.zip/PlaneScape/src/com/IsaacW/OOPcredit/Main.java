package com.IsaacW.OOPcredit;

import java.util.Scanner;

public class Main
{
    //initialize rooms and player
    private static Player player = new Player();
    private static Cockpit cockpit = new Cockpit("cockpit");
    private static Cabin cabin = new Cabin("cabin");

    //initialize input reader
    private static Scanner s = new Scanner(System.in);


    /**
     * Main method that controls the sequence of the game.
     *
     * @throws InterruptedException prevents errors with thread.sleep()
     */
    public static void main(String[] args) throws InterruptedException
    {
	    double movesLeft = 6;
	    double minutes;
	    int runCode = 99;

        introSequence();

        //action loop gets commands and executes them
        //run codes determine if player loses/wins/special conditions
        while (movesLeft > 0)
        {
            System.out.println("-------------------------");
            System.out.println("You are in the " + player.whichRoom() + ".");
            minutes = movesLeft / 2;
            System.out.println("You have " + minutes + " minutes left. \n");

            runCode = act(ask());

            if (runCode == 0) //player made an invalid move
            {
                continue;
            }
            else if (runCode == 1 || runCode == 3) //player won (1), lost (2), jumped early (3)
            {
                break;
            }
            else
            {
                movesLeft--;
            }

            if (movesLeft == 0)
            {
                runCode = 2;
            }
        }

        endingControl(runCode);

    }

    /**
     * Introduction story: gives context and instructions
     *
     * @throws InterruptedException prevents errors with thread.sleep()
     */
    private static void introSequence() throws InterruptedException
    {
        System.out.println("Starting PlaneScape, an escape game...");
        Thread.sleep(2000);
        System.out.println("*************************\n");

        System.out.println(
           "You were on an airplane with Daffy Duck travelling to Albuquerque to visit your friend Bugs Bunny, \n" +
           "when suddenly, the engine blew out.  As the airplane began to spiral into the ground, \n" +
           "the pilot was knocked unconscious.  You realize you need to parachute out, but Daffy has just \n" +
           "jumped out with the last parachute.  With only 3 minutes until the plane is too close to the ground to \n" +
           "escape crashing, you need to get out."
        );

        Thread.sleep(11000);

        System.out.println("*************************");
        System.out.println("You can do one of three action: ");
        System.out.println("1. When you are in a room, you can use the “loot” command to find any materials");
        System.out.println("2. Switch areas: type the area’s name [cockpit or cabin]");
        System.out.println("3. Merge any items you may have: type \"merge\" \n");
        System.out.println("Each action costs ½ minute.  Invalid moves don't cost anything.");
        System.out.println("*************************");

        Thread.sleep(5000);

    }

    /**
     * Storyline for player winning
     */
    private static void printWin(){
        System.out.println("\nCongratulations! You win!" +
                "\nYou successfully made a parachute" +
                "\nand jumped from the plane before it crashed!" +
                "\nYou reach the ground and catch a ride" +
                "\nto Bug's Bunny's house on Wile E Coyote's" +
                "\nAcme Rocket Sled!");
    }

    /**
     * Storyline for player running out of moves
     */
    private static void printTimeout()
    {
        System.out.println("\nYou have run out of time!" +
                "\nYou lose the game--however, you" +
                "\nare just a cartoon so you can't really die..." +
                "\nYou crash!");
    }

    /**
     * Storyline for player jumping without chute
     */
    private static void printJumpEarly()
    {
        System.out.println("\nYou run to the cabin door and " +
                "\njump out of the plane.  In typical" +
                "\ncartoon fashion, you realize you have" +
                "\nno parachute and try to run back while in" +
                "\nmidair but fall before you get back." +
                "\nYou lose the game--however, you" +
                "\nare just a cartoon so you can't really die..."
        );
    }

    /**
     * Asks for the player's commands.
     *
     * @return the player's command in lowercase
     */
    private static String ask()
    {
        String move;

        System.out.print("Action: ");
        move = s.next();

        return move.toLowerCase();

    }

    /**
     * Takes the player's command and executes it.
     *
     * @param move the player's command
     * @return the run code for determining if player's situation
     */
    private static int act(String move) throws InterruptedException
    {
        int runCode = 99;

        if (move.equals("loot"))//loots the room the player is in
        {
            System.out.println("\n Attempting to loot " + player.whichRoom() + "...");
            Thread.sleep(1000);

            if (player.whichRoom().equals("cockpit") && !cockpit.isLooted())
            {
                player.add(cockpit.loot());
            }
            else if (player.whichRoom().equals("cabin") && !cabin.isLooted())
            {
                player.add(cabin.loot());
            }
            else
            {
                System.out.println("\n Room is already looted. \n");
            }

        }
        else if (move.equals("cockpit"))
        {
            player.goTo("cockpit");
        }
        else if (move.equals("cabin"))
        {
            player.goTo("cabin");
        }
        else if (move.equals("merge"))
        {
            player.merge();
        }
        else if (move.equals("jump"))
        {
            if (player.isJumpEnabled() && player.whichRoom().equals("cabin"))
            {
                runCode = 1;
            }
            else if (player.isJumpEnabled() && !player.whichRoom().equals("cabin"))
            {
                System.out.println("\nYou attempt to jump, but there"
                + "\nare no escapes in the cockpit so you" +
                        "\njust smack into the wall. \n");
            }
            else if (!player.isJumpEnabled())
            {
                runCode = 3;
            }
        }
        else if (move.equals("2019"))//easter egg function call
        {
            player.egg();
            runCode = 1;
        }
        else
        {
            System.out.println("\n Invalid move. \n");
            runCode = 0;
        }

        Thread.sleep(200);
        return runCode;
    }

    /**
     * Determines the player's fate.
     *
     * @param runCode the condition code for determining outcome
     * @throws InterruptedException prevents Thread.sleep() from throwing errors
     */
    private static void endingControl(int runCode) throws InterruptedException
    {
        System.out.println("*************************");

        if (runCode == 1)//won
        {
            printWin();
        }
        else if (runCode == 2)//lost
        {
            printTimeout();
        }
        else if (runCode == 3)//jumped early
        {
            printJumpEarly();
        }

        Thread.sleep(5000);
        System.out.println("\n*************************" +
                "\n That's all Folks!");

    }
}
