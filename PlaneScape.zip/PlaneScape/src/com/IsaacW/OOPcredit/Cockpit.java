package com.IsaacW.OOPcredit;

public class Cockpit extends Room
{
    private Thing blanket = new Thing("blanket");

    public Cockpit(String name)
    {
        super(name);
    }

    /**
     * Loots the room by returning its object.
     *
     * @return the looted object
     */
    public Thing loot()
    {
        System.out.println("\n You have found a blanket. \n");
        super.doneLoot();
        return blanket;
    }

}
