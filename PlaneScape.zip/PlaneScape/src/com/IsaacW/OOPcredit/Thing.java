package com.IsaacW.OOPcredit;

public class Thing
{
    private String name;

    public Thing(String name)
    {
        this.name = name;
    }

    /**
     * Lets the caller know the name of the object.
     *
     * @return the object's name
     */
    public String toString() {
        return name;
    }
}
