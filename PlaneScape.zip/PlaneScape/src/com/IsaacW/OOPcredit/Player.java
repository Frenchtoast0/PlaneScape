package com.IsaacW.OOPcredit;

import java.util.ArrayList;

public class Player
{
    private static String room;
    private static ArrayList<Thing> inventory = new ArrayList<Thing>();

    private static boolean jumpEnabled = false;

    public Player()
    {
        room = "cabin";
    }

    /**
     * If all objects present, the player will merge
     * the objects to form a parachute and allow
     * the player to jump.
     */
    public void merge()
    {
        if (inventory.size() == 2)
        {
            System.out.println("\n Successfully merged objects!");
            System.out.println("You now can use the \"jump\"! command when in the right place. \n");

            jumpEnabled = true;
        }
        else
        {
            System.out.println("\n Missing needed object. \n");
        }
    }

    /**
     * Switches the player's location.
     *
     * @param room room to move to
     */
    public void goTo(String room)
    {
        if (this.room.equals(room))
        {
            System.out.println("\n You are already in the " + room + ". \n");
            System.out.println("Your state of bewilderment has costed you time!\n");
        }
        else
        {
            System.out.println("\n You are now in the " + room + ". \n");
            this.room = room;
        }

    }

    /**
     * Checks if the player has a parachute created
     * so it can jump.
     *
     * @return whether or not player can jump safely
     */
    public boolean isJumpEnabled()
    {
        return jumpEnabled;
    }

    public void add(Thing object)
    {
        inventory.add(object);
    }

    public String whichRoom()
    {
        return room;
    }


    /**
     * Easter Egg function gives credits and gives
     * an instant win.
     */
    public void egg()
    {
        System.out.println("\n Created by Isaac Wittmeier");
        System.out.println("For finding this, you win the game! \n");
    }
}
