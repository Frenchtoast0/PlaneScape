package com.IsaacW.OOPcredit;

public class Cabin extends Room
{
    private Thing backpackRope = new Thing("backpackRope");

    public Cabin(String name)
    {
        super(name);
    }

    /**
     * Loots the room by returning its object.
     *
     * @return the looted object
     */
    public Thing loot()
    {
        System.out.println("\n You have found a backpack and rope. \n");
        super.doneLoot();
        return backpackRope;
    }

}
